package edu.uga.cs.pantrypal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PantrypalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PantrypalApplication.class, args);
	}

}
